package com.example.splash.Json;

public class MyData {
    private String passRed;
    private String contra;

    public String getPassRed() {
        return passRed;
    }

    public void setPassRed(String passRed) {
        this.passRed = passRed;
    }

    private int perfil;

    public int getPerfil() {
        return perfil;
    }

    public void setPerfil(int perfil) {
        this.perfil = perfil;
    }

    public String getRed() {
        return red;
    }

    public void setRed(String red) {
        this.red = red;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    private String red;
}