package com.example.splash.utils;

public class Constant {
    public final static String DEBUG_POKEMON = "DEBUG_POKEMON";
}
